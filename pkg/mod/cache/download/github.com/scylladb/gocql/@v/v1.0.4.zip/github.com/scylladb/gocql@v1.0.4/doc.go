// Copyright (c) 2012-2015 The gocql Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package gocql implements a fast and robust Cassandra driver for the
// Go programming language.
package gocql // import "github.com/gocql/gocql"

// TODO(tux21b): write more docs.
